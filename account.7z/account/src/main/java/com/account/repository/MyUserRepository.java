package com.account.repository;

import com.account.model.User;


public interface MyUserRepository {

	User getMyRole(String username);
}
